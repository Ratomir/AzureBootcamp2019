Param(
    [Parameter(Mandatory = $True, HelpMessage = "SQL Server Resource group")]
    [string]$sqlServerResourceGroupName,

    [Parameter(Mandatory = $True, HelpMessage = "Server name")]
    [string]$serverName,

    [Parameter(Mandatory = $True, HelpMessage = "Database name")]
    [string]$databaseName,

    [Parameter(Mandatory = $True, HelpMessage = "Edition")]
    [string]$edition,

    [Parameter(Mandatory = $True, HelpMessage = "Service objective name")]
    [string]$serviceObjectiveName
)

Set-AzureRmSqlDatabase -ResourceGroupName $sqlServerResourceGroupName `
    -ServerName $serverName `
    -DatabaseName $databaseName  `
    -Edition $edition `
    -RequestedServiceObjectiveName $serviceObjectiveName