[CmdletBinding(DefaultParameterSetName = 'None')]
param
(
  [String] [Parameter(Mandatory = $true)] $server,
  [String] [Parameter(Mandatory = $true)] $resourcegroup,
  [String] [Parameter(Mandatory = $true)] $dbname,
  [String] [Parameter(Mandatory = $true)] $serverfullname
)

try {
  $databaseObject = az sql db show --name $dbname --resource-group $resourcegroup --server $server
}
catch {
  
az sql db create -g $resourcegroup -s $server -n $dbname --service-objective Basic
## Specify the DAC metadata.  
$applicationname = $dbname  
$version = "1.0.0.0"  
$description = "This DAC defines the database used by my application."  
  
## Register the DAC.  
# $registerunit = New-Object Microsoft.SqlServer.Management.Dac.DacExtractionUnit($serverfullname, $dbname, $applicationname, $version)  
# $registerunit.Description = $description  
# $registerunit.Register()
}


